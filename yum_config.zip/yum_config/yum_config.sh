#!/bin/sh

sudo rpm -aq|grep yum|xargs sudo rpm -e --nodeps 
sudo rpm -ivh python-iniparse-0.3.1-2.1.el6.noarch.rpm 
sudo rpm -ivh yum-metadata-parser-1.1.2-16.el6.x86_64.rpm 
sudo rpm -ivh yum-3.2.29-60.el6.centos.noarch.rpm yum-plugin-fastestmirror-1.1.30-30.el6.noarch.rpm  
sudo mv /etc/yum.repos.d/rhel-source.repo /etc/yum.repos.d/rhel-source.bak
sudo cp ./rhel-source.repo /etc/yum.repos.d/rhel-source.repo
sudo cp ./CentOS6-Base-163.repo /etc/yum.repos.d/CentOS6-Base-163.repo
sudo yum clean all 
sudo yum makecache
